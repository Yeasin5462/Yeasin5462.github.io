let eventDate;
let countdownText;

function setup() {
  createCanvas(windowWidth, windowHeight);
  textAlign(CENTER, CENTER);
  textSize(40);
  fill(255);

  // Set the event date: year, month (0-11), day, hour, minute, second
  eventDate = new Date(2023, 11, 31, 23, 59, 59); // Example: New Year's Eve
}

function draw() {
  background(0);
  let currentTime = new Date();
  let timeLeft = eventDate - currentTime;

  if (timeLeft > 0) {
    let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

    countdownText = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
  } else {
    countdownText = "The event has started!";
  }

  text(countdownText, width / 2, height / 2);
}
